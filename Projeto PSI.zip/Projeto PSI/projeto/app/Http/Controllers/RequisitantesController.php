<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Requisitante;
class RequisitantesController extends Controller
{
    //
           public function index(){

	$requisitantes= Requisitante::paginate(8);

	return view ('requisitantes.index', ['requisitantes'=>$requisitantes]);
}
public function show (Request $request){
	$idRequisitante=$request->id;

	$requisitante=Requisitante::where('id_requisitante', $idRequisitante)->with('requisitantes')->first();
	
	return view ('requisitantes.show',['requisitante'=>$requisitante]);
}
}
