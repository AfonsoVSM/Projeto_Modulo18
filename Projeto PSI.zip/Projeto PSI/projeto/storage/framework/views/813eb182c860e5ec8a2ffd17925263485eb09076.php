<ul>
<?php $__currentLoopData = $materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('materiais.show', ['id'=>$material->id_material])); ?>">
 <?php echo e($material->designacao); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($materiais->render()); ?><?php /**PATH C:\Users\Paulo Costa\Desktop\Projeto PSI\projeto\resources\views/materiais/index.blade.php ENDPATH**/ ?>