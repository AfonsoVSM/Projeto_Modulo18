<b>ID:</b>{{$requisitante->id_requisitante}}<br>
<br>
<b>Nome:</b>{{$requisitante->nome}}<br>
<br>
<b>Telefone:</b>{{$requisitante->telefone}}<br>
<br>
<b>Email:</b>{{$requisitante->email}}<br>
<br>
<b>Localidade:</b>{{$requisitante->localidade}}<br>
<br>
<b>Cartao_Cidadao:</b>{{$requisitante->cartao_cidadao}}<br>
<br>
<h1><i>Tipos de Equipamentos:</b></h1></i>
<h1>Computadores</h1>

