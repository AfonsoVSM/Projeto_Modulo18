@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('conteudo')

<ul>
@foreach($requisitantes as $requisitante)
<li>
<a href="{{route('requisitantes.show', ['id'=>$requisitante->id_requisitante])}}">
 {{$requisitante->nome}}</a></li>
@endforeach
</ul>
{{$requisitantes->render()}}

@endsection

@section('rodapé')

@endsection
